<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cheque_emitido extends Model
{
    protected $table = 'cheques_emitido';
    use HasFactory;
}
