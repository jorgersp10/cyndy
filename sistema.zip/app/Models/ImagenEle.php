<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImagenEle extends Model
{
    protected $table = 'electro_img';

    use HasFactory;
}
