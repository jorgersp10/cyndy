<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Precio_historico extends Model
{
    protected $table = 'precios_historico';
    use HasFactory;
}
