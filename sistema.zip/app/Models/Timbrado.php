<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Timbrado extends Model
{
    protected $table = 'timbrados';

    protected $fillable=['timbrado'];
}
