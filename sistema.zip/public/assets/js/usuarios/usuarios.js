$(function() {

    var sucursal_id_h=document.getElementById("sucursal_id_hidden").value;
    document.getElementById("idsucursal").value = sucursal_id_h;

    var rol_id_h=document.getElementById("rol_id_hidden").value;
    console.log(rol_id_h);
    document.getElementById("id_rol").value = rol_id_h;

});