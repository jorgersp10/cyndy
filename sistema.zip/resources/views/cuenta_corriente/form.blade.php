     
   
    <div class="row mb-4">
                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Sucursal</label>
                <div class="col-sm-9">
                    <input type="text" id="sucursal" name="sucursal" class="form-control" placeholder="Ingrese el Nombre">
                    
                </div>
    </div>

    <div class="modal-footer">
        <button type="submit" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>